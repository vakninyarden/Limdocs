import json
import logging
import os
from datetime import datetime, timezone
from uuid import uuid4

import boto3

DOCUMENTS_TABLE = os.environ["DOCUMENTS_TABLE"]
QUESTIONS_TABLE = os.environ["QUESTIONS_TABLE"]
QUESTION_SETS_TABLE = os.environ["QUESTION_SETS_TABLE"]
PROCESSED_BUCKET = os.environ["PROCESSED_BUCKET"]
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]
OPENAI_MODEL_NAME = os.environ["OPENAI_MODEL_NAME"]

_MAX_SOURCE_CHARS = 12000
_ALLOWED_DIFFICULTIES = {"Easy", "Medium", "Hard"}

logger = logging.getLogger()
logger.setLevel(logging.INFO)

_dynamodb = boto3.resource("dynamodb")
_s3 = boto3.client("s3")
_documents_table = _dynamodb.Table(DOCUMENTS_TABLE)
_questions_table = _dynamodb.Table(QUESTIONS_TABLE)
_question_sets_table = _dynamodb.Table(QUESTION_SETS_TABLE)

_CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
}

_SYSTEM_PROMPT = (
    "You are an expert academic assistant. Generate 5 high-quality multiple-choice "
    "questions in Hebrew based on the provided text. Categorize each question with "
    "relevant topics and assign difficulty as Easy, Medium, or Hard based on the "
    "academic depth of the text. Return ONLY a valid JSON array of objects."
)


def _response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": _CORS_HEADERS,
        "body": json.dumps(payload, ensure_ascii=False),
    }


def _clean_model_json(raw_text):
    text = (raw_text or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    if text.lower().startswith("json"):
        text = text[4:].strip()
    return text


def _truncate_source_text(text):
    if len(text) <= _MAX_SOURCE_CHARS:
        return text
    return text[:_MAX_SOURCE_CHARS]


def _normalize_question(item):
    if not isinstance(item, dict):
        return None

    question = item.get("question")
    options = item.get("options")
    correct_index = item.get("correct_index")
    explanation = item.get("explanation")
    topics = item.get("topics")
    difficulty = item.get("difficulty")

    if not isinstance(question, str) or not question.strip():
        return None
    if not isinstance(explanation, str) or not explanation.strip():
        return None
    if not isinstance(options, list) or len(options) != 4:
        return None
    if any(not isinstance(opt, str) or not opt.strip() for opt in options):
        return None
    if not isinstance(correct_index, int) or correct_index < 0 or correct_index > 3:
        return None
    if not isinstance(topics, list) or any(not isinstance(topic, str) or not topic.strip() for topic in topics):
        return None
    if not isinstance(difficulty, str) or difficulty not in _ALLOWED_DIFFICULTIES:
        return None

    return {
        "question": question.strip(),
        "options": [opt.strip() for opt in options],
        "correct_index": correct_index,
        "explanation": explanation.strip(),
        "topics": [topic.strip() for topic in topics if topic.strip()],
        "difficulty": difficulty,
    }


def _parse_valid_questions(raw_response):
    cleaned = _clean_model_json(raw_response)
    parsed = json.loads(cleaned)
    if not isinstance(parsed, list):
        raise ValueError("Model response must be a JSON array")

    valid = []
    discarded = 0
    for item in parsed:
        normalized = _normalize_question(item)
        if normalized is None:
            discarded += 1
            continue
        valid.append(normalized)
    return valid, discarded


def lambda_handler(event, context):
    del context
    try:
        claims = (
            event.get("requestContext", {})
            .get("authorizer", {})
            .get("claims", {})
        )
        if not claims.get("sub"):
            return _response(401, {"message": "Unauthorized: missing user identity"})

        path_parameters = event.get("pathParameters", {})
        course_id = path_parameters.get("courseId")
        document_id = path_parameters.get("documentId")
        if not course_id:
            return _response(400, {"message": "Missing path parameter: courseId"})
        if not document_id:
            return _response(400, {"message": "Missing path parameter: documentId"})

        result = _documents_table.get_item(Key={"document_id": document_id})
        item = result.get("Item")
        if not item:
            return _response(404, {"message": "Document not found"})

        if item.get("course_id") != course_id:
            return _response(403, {"message": "Forbidden"})

        processed_key = item.get("s3_processed_key")
        if not processed_key:
            return _response(400, {"message": "Document is not processed yet"})

        try:
            s3_obj = _s3.get_object(Bucket=PROCESSED_BUCKET, Key=processed_key)
            source_text = s3_obj["Body"].read().decode("utf-8", errors="replace")
        except Exception:
            logger.exception(
                "Failed reading processed text from S3 for document_id=%s key=%s",
                document_id,
                processed_key,
            )
            return _response(500, {"message": "Failed to load processed document text"})

        input_text = _truncate_source_text(source_text)
        logger.info(
            "Loaded source text for document_id=%s original_len=%s truncated_len=%s",
            document_id,
            len(source_text),
            len(input_text),
        )

        try:
            from openai import OpenAI

            client = OpenAI(api_key=OPENAI_API_KEY)
            completion = client.chat.completions.create(
                model=OPENAI_MODEL_NAME,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": input_text},
                ],
                temperature=0.2,
            )
            raw_response = completion.choices[0].message.content or ""
            valid_questions, discarded_count = _parse_valid_questions(raw_response)
        except Exception:
            logger.exception(
                "OpenAI generation/parsing failed for document_id=%s model=%s",
                document_id,
                OPENAI_MODEL_NAME,
            )
            return _response(502, {"message": "Failed generating questions from AI response"})

        logger.info(
            "AI generation complete for document_id=%s valid=%s discarded=%s",
            document_id,
            len(valid_questions),
            discarded_count,
        )
        if not valid_questions:
            return _response(
                422,
                {"message": "AI response contained no valid questions"},
            )

        set_id = str(uuid4())
        created_at = datetime.now(timezone.utc).isoformat()

        _question_sets_table.put_item(
            Item={
                "set_id": set_id,
                "document_id": document_id,
                "course_id": course_id,
                "created_at": created_at,
            }
        )

        with _questions_table.batch_writer() as batch:
            for question in valid_questions:
                batch.put_item(
                    Item={
                        "question_id": str(uuid4()),
                        "set_id": set_id,
                        "question": question["question"],
                        "options": question["options"],
                        "correct_index": question["correct_index"],
                        "explanation": question["explanation"],
                        "topics": question["topics"],
                        "difficulty": question["difficulty"],
                    }
                )

        _documents_table.update_item(
            Key={"document_id": document_id},
            UpdateExpression="SET processing_status = :status",
            ExpressionAttributeValues={":status": "GENERATED"},
        )

        logger.info(
            "Persisted question set document_id=%s set_id=%s inserted=%s",
            document_id,
            set_id,
            len(valid_questions),
        )
        return _response(
            200,
            {
                "message": "Questions generated successfully",
                "set_id": set_id,
                "document_id": document_id,
                "course_id": course_id,
                "inserted_questions": len(valid_questions),
                "discarded_questions": discarded_count,
            },
        )
    except Exception as exc:
        logger.exception("Unhandled error in generate_questions for event")
        return _response(500, {"message": "Internal server error", "error": str(exc)})
