import json
import os

import boto3


DOCUMENTS_TABLE = os.environ["DOCUMENTS_TABLE"]
UPLOAD_BUCKET = os.environ["UPLOAD_BUCKET"]
_dynamodb = boto3.resource("dynamodb")
_table = _dynamodb.Table(DOCUMENTS_TABLE)
_s3 = boto3.client("s3")

_CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
}


def _response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": _CORS_HEADERS,
        "body": json.dumps(payload),
    }


def lambda_handler(event, context):
    del context
    try:
        claims = (
            event.get("requestContext", {})
            .get("authorizer", {})
            .get("claims", {})
        )
        sub = claims.get("sub")
        if not sub:
            return _response(401, {"message": "Unauthorized: missing user identity"})

        path_parameters = event.get("pathParameters", {})
        course_id = path_parameters.get("courseId")
        document_id = path_parameters.get("documentId")
        if not course_id:
            return _response(400, {"message": "Missing path parameter: courseId"})
        if not document_id:
            return _response(400, {"message": "Missing path parameter: documentId"})

        result = _table.get_item(Key={"document_id": document_id})
        item = result.get("Item")
        if not item:
            return _response(404, {"message": "Document not found"})

        if item.get("uploader_user_name") != sub or item.get("course_id") != course_id:
            return _response(403, {"message": "Forbidden"})

        s3_raw_key = item.get("s3_raw_key")
        if not s3_raw_key:
            return _response(500, {"message": "Document metadata missing storage key"})

        try:
            # Keep storage and metadata consistent: delete object first, then metadata.
            _s3.delete_object(Bucket=UPLOAD_BUCKET, Key=s3_raw_key)
            _table.delete_item(Key={"document_id": document_id})
            # TODO: When Textract pipeline is added, also delete generated artifacts from processed outputs bucket.
        except Exception as exc:
            return _response(
                500,
                {
                    "message": "Failed to delete document assets",
                    "error": str(exc),
                },
            )

        return _response(200, {"message": "Document deleted successfully"})
    except Exception as exc:
        return _response(500, {"message": "Internal server error", "error": str(exc)})
